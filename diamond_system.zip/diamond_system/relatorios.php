<?php
require_once 'configuracao/config.php';
require_once 'classes/Venda.php';
require_once 'classes/Produto.php';

check_permission(['admin', 'manager']);

$conn = db_connect();
$sale = new Sale($conn);
$product = new Product($conn);

$period = $_GET['period'] ?? 'month';
$export = $_GET['export'] ?? '';

$start_date = '';
$end_date = date('Y-m-d');

switch ($period) {
    case 'today':
        $start_date = date('Y-m-d');
        break;
    case 'week':
        $start_date = date('Y-m-d', strtotime('-7 days'));
        break;
    case 'month':
        $start_date = date('Y-m-d', strtotime('-30 days'));
        break;
    case 'year':
        $start_date = date('Y-m-d', strtotime('-365 days'));
        break;
    case 'custom':
        $start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
        $end_date = $_GET['end_date'] ?? date('Y-m-d');
        break;
}

$sales_report = $sale->getSalesReport($start_date, $end_date);
$top_products = $sale->getTopProducts(10, $start_date, $end_date);
$top_clients = $sale->getTopClients(10, $start_date, $end_date);
$sales_by_payment = $sale->getSalesByPaymentMethod($start_date, $end_date);
$daily_sales = $sale->getDailySales($start_date, $end_date);

if ($export == 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="relatorio_vendas_' . date('Y-m-d') . '.xls"');
    
    echo "<html><head><meta charset='utf-8'></head><body>";
    echo "<h1>Relatório de Vendas - " . date('d/m/Y', strtotime($start_date)) . " a " . date('d/m/Y', strtotime($end_date)) . "</h1>";
    
    echo "<h2>Resumo Geral</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Total de Vendas</th><td>" . format_money($sales_report['total_sales']) . "</td></tr>";
    echo "<tr><th>Número de Vendas</th><td>" . $sales_report['num_sales'] . "</td></tr>";
    echo "<tr><th>Ticket Médio</th><td>" . format_money($sales_report['avg_ticket']) . "</td></tr>";
    echo "</table><br>";
    
    echo "<h2>Produtos Mais Vendidos</h2>";
    echo "<table border='1'><tr><th>#</th><th>Produto</th><th>Quantidade</th><th>Receita</th></tr>";
    $pos = 1;
    foreach ($top_products as $p) {
        echo "<tr><td>{$pos}º</td><td>{$p['name']}</td><td>{$p['total_sold']}</td><td>" . format_money($p['revenue']) . "</td></tr>";
        $pos++;
    }
    echo "</table>";
    
    echo "</body></html>";
    exit;
}

if ($export == 'pdf') {
    $html = '<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Vendas - ' . date('d/m/Y', strtotime($start_date)) . ' a ' . date('d/m/Y', strtotime($end_date)) . '</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            padding: 20px;
            background: white;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #3b82f6;
        }
        h1 { 
            color: #3b82f6; 
            margin-bottom: 10px;
            font-size: 28px;
        }
        .period { 
            color: #666; 
            font-size: 14px;
        }
        h2 { 
            color: #1e40af; 
            margin: 30px 0 15px 0;
            font-size: 20px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 20px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        th { 
            background-color: #3b82f6; 
            color: white; 
            padding: 12px; 
            text-align: left;
            font-weight: bold;
        }
        td { 
            padding: 10px 12px; 
            border-bottom: 1px solid #e5e7eb;
        }
        tr:nth-child(even) {
            background-color: #f9fafb;
        }
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #3b82f6;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
            transition: all 0.3s;
        }
        .print-button:hover {
            background: #2563eb;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(59, 130, 246, 0.4);
        }
        @media print {
            .print-button { display: none; }
            body { padding: 0; }
        }
        @page {
            size: A4;
            margin: 2cm;
        }
    </style>
</head>
<body>
    <button class="print-button" onclick="window.print()">
        <i class="fas fa-print"></i> Imprimir / Salvar como PDF
    </button>
    
    <div class="header">
        <h1>Relatório de Vendas - Diamond System</h1>
        <p class="period"><strong>Período:</strong> ' . date('d/m/Y', strtotime($start_date)) . ' a ' . date('d/m/Y', strtotime($end_date)) . '</p>
    </div>
    
    <h2>Resumo Geral</h2>
    <table>
        <tr><th style="width: 60%;">Métrica</th><th style="width: 40%;">Valor</th></tr>
        <tr><td>Total de Vendas</td><td><strong>' . format_money($sales_report['total_sales']) . '</strong></td></tr>
        <tr><td>Número de Vendas</td><td><strong>' . $sales_report['num_sales'] . '</strong></td></tr>
        <tr><td>Ticket Médio</td><td><strong>' . format_money($sales_report['avg_ticket']) . '</strong></td></tr>
    </table>
    
    <h2>Produtos Mais Vendidos</h2>
    <table>
        <thead>
            <tr>
                <th style="width: 10%;">#</th>
                <th style="width: 50%;">Produto</th>
                <th style="width: 20%;">Quantidade</th>
                <th style="width: 20%;">Receita</th>
            </tr>
        </thead>
        <tbody>';
    
    $pos = 1;
    foreach ($top_products as $p) {
        $html .= '<tr>
            <td>' . $pos . 'º</td>
            <td>' . htmlspecialchars($p['name']) . '</td>
            <td>' . $p['total_sold'] . '</td>
            <td><strong>' . format_money($p['revenue']) . '</strong></td>
        </tr>';
        $pos++;
    }
    
    $html .= '</tbody>
    </table>
    
    <script>
        // Abrir automaticamente a dialog de impressão após carregar
        window.onload = function() {
            setTimeout(function() {
                // Comentar a linha abaixo se não quiser abrir automaticamente
                // window.print();
            }, 500);
        };
    </script>
</body>
</html>';
    
    echo $html;
    exit;
}

$page_title = 'Relatórios';

require_once 'inclusoes/cabecalho.php';
require_once 'inclusoes/menu_lateral.php';
?>

<style>
.metric-card {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 16px;
    padding: 24px;
    transition: all 0.3s ease;
}

.metric-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 40px rgba(59, 130, 246, 0.2);
}

.metric-icon {
    width: 56px;
    height: 56px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.metric-value {
    font-size: 28px;
    font-weight: 800;
    color: var(--white-text);
    margin: 8px 0 4px 0;
}

.metric-label {
    font-size: 13px;
    color: var(--muted-text);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.report-filters {
    background: rgba(59, 130, 246, 0.05);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
}

.export-buttons .btn {
    border-radius: 8px;
    font-weight: 600;
}
</style>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-4 border-bottom">
    <h1 class="h2"><i class="fas fa-chart-bar me-2"></i>Relatórios de Vendas</h1>
    <div class="export-buttons">
        <a href="?period=<?php echo $period; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&export=excel" class="btn btn-success btn-sm">
            <i class="fas fa-file-excel me-1"></i> Exportar Excel
        </a>
        <button onclick="gerarPDF()" class="btn btn-danger btn-sm">
            <i class="fas fa-file-pdf me-1"></i> Exportar PDF
        </button>
    </div>
</div>

<div class="report-filters">
    <form method="get" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label">Período</label>
            <select name="period" class="form-select" id="periodSelect" onchange="toggleCustomDates()">
                <option value="today" <?php echo $period == 'today' ? 'selected' : ''; ?>>Hoje</option>
                <option value="week" <?php echo $period == 'week' ? 'selected' : ''; ?>>Últimos 7 dias</option>
                <option value="month" <?php echo $period == 'month' ? 'selected' : ''; ?>>Últimos 30 dias</option>
                <option value="year" <?php echo $period == 'year' ? 'selected' : ''; ?>>Último ano</option>
                <option value="custom" <?php echo $period == 'custom' ? 'selected' : ''; ?>>Personalizado</option>
            </select>
        </div>
        <div class="col-md-3 custom-dates" style="display: <?php echo $period == 'custom' ? 'block' : 'none'; ?>">
            <label class="form-label">Data Inicial</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
        </div>
        <div class="col-md-3 custom-dates" style="display: <?php echo $period == 'custom' ? 'block' : 'none'; ?>">
            <label class="form-label">Data Final</label>
            <input type="date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-search me-1"></i> Filtrar
            </button>
        </div>
    </form>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="metric-card">
            <div class="d-flex align-items-center">
                <div class="metric-icon" style="background: linear-gradient(135deg, #3b82f6, #2563eb); color: white;">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="ms-3 flex-grow-1">
                    <div class="metric-label">Receita Total</div>
                    <div class="metric-value"><?php echo format_money($sales_report['total_sales']); ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="metric-card">
            <div class="d-flex align-items-center">
                <div class="metric-icon" style="background: linear-gradient(135deg, #10b981, #059669); color: white;">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="ms-3 flex-grow-1">
                    <div class="metric-label">Total de Vendas</div>
                    <div class="metric-value"><?php echo $sales_report['num_sales']; ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="metric-card">
            <div class="d-flex align-items-center">
                <div class="metric-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white;">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="ms-3 flex-grow-1">
                    <div class="metric-label">Ticket Médio</div>
                    <div class="metric-value"><?php echo format_money($sales_report['avg_ticket']); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-chart-area me-2"></i>Vendas por Dia</h5>
            </div>
            <div class="card-body">
                <canvas id="dailySalesChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-credit-card me-2"></i>Formas de Pagamento</h5>
            </div>
            <div class="card-body">
                <canvas id="paymentChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-trophy me-2"></i>Top 10 Produtos</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Produto</th>
                                <th>Qtd.</th>
                                <th>Receita</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $pos = 1; ?>
                            <?php foreach ($top_products as $p): ?>
                            <tr>
                                <td>
                                    <span class="badge" style="background: linear-gradient(135deg, #3b82f6, #8b5cf6);">
                                        <?php echo $pos++; ?>º
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($p['name']); ?></td>
                                <td><span class="badge bg-primary"><?php echo $p['total_sold']; ?></span></td>
                                <td><strong><?php echo format_money($p['revenue']); ?></strong></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-users me-2"></i>Top 10 Clientes</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Cliente</th>
                                <th>Compras</th>
                                <th>Total Gasto</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $pos = 1; ?>
                            <?php foreach ($top_clients as $c): ?>
                            <tr>
                                <td>
                                    <span class="badge" style="background: linear-gradient(135deg, #10b981, #059669);">
                                        <?php echo $pos++; ?>º
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($c['client_name'] ?: 'Não registrado'); ?></td>
                                <td><span class="badge bg-info"><?php echo $c['num_purchases']; ?></span></td>
                                <td><strong><?php echo format_money($c['total_spent']); ?></strong></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function gerarPDF() {
    const period = '<?php echo $period; ?>';
    const startDate = '<?php echo $start_date; ?>';
    const endDate = '<?php echo $end_date; ?>';
    
    const url = `?period=${period}&start_date=${startDate}&end_date=${endDate}&export=pdf`;
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio_vendas_${startDate}_${endDate}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function toggleCustomDates() {
    const period = document.getElementById('periodSelect').value;
    const customDates = document.querySelectorAll('.custom-dates');
    customDates.forEach(el => {
        el.style.display = period === 'custom' ? 'block' : 'none';
    });
}

const dailySalesData = <?php echo json_encode($daily_sales); ?>;
const paymentData = <?php echo json_encode($sales_by_payment); ?>;

const dailySalesCtx = document.getElementById('dailySalesChart').getContext('2d');
const dailyGradient = dailySalesCtx.createLinearGradient(0, 0, 0, 350);
dailyGradient.addColorStop(0, 'rgba(59, 130, 246, 0.8)');
dailyGradient.addColorStop(0.4, 'rgba(59, 130, 246, 0.4)');
dailyGradient.addColorStop(1, 'rgba(59, 130, 246, 0.05)');

new Chart(dailySalesCtx, {
    type: 'line',
    data: {
        labels: dailySalesData.map(d => {
            const date = new Date(d.date);
            return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
        }),
        datasets: [{
            label: 'Vendas (R$)',
            data: dailySalesData.map(d => parseFloat(d.total)),
            borderColor: '#3b82f6',
            backgroundColor: dailyGradient,
            borderWidth: 4,
            fill: true,
            tension: 0.5,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: '#3b82f6',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            showLine: true,
            spanGaps: true,
            cubicInterpolationMode: 'monotone',
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'R$ ' + value.toFixed(2);
                    }
                }
            }
        }
    }
});

const paymentCtx = document.getElementById('paymentChart').getContext('2d');
new Chart(paymentCtx, {
    type: 'doughnut',
    data: {
        labels: paymentData.map(d => d.payment_method),
        datasets: [{
            data: paymentData.map(d => parseFloat(d.total)),
            backgroundColor: [
                '#3b82f6',
                '#10b981',
                '#8b5cf6',
                '#f59e0b',
                '#ef4444'
            ],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 15,
                    font: {
                        size: 12
                    }
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.label + ': R$ ' + parseFloat(context.raw).toFixed(2);
                    }
                }
            }
        }
    }
});
</script>

<?php
db_close($conn);
require_once 'inclusoes/rodape.php';
?>
