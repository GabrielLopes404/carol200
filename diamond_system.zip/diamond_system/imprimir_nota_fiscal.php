<?php
require_once 'configuracao/config.php';
require_once 'classes/Venda.php';

require_login();

$sale_id = (int)($_GET['id'] ?? 0);

if ($sale_id <= 0) {
    display_error('Venda não encontrada.');
    redirect(BASE_URL . 'vendas.php');
}

$conn = db_connect();
$sale_obj = new Sale($conn);
$sale = $sale_obj->getById($sale_id);

if (!$sale) {
    display_error('Venda não encontrada.');
    db_close($conn);
    redirect(BASE_URL . 'vendas.php');
}

$items = $sale_obj->getItems($sale_id);
db_close($conn);

$nota_numero = str_pad($sale['id'], 6, '0', STR_PAD_LEFT);
$data_emissao = date('d/m/Y H:i:s', strtotime($sale['sale_date']));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Fiscal #<?php echo $nota_numero; ?> - Diamond System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @media print {
            body {
                margin: 0;
                padding: 15mm;
            }
            
            .no-print {
                display: none !important;
            }
            
            @page {
                size: A4;
                margin: 0;
            }
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }
        
        .container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }
        
        .header {
            text-align: center;
            border-bottom: 3px solid #3b82f6;
            padding-bottom: 25px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #3b82f6;
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 8px;
            letter-spacing: 1px;
        }
        
        .header .subtitle {
            color: #666;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .nota-info {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-left: 5px solid #3b82f6;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
        }
        
        .nota-info table {
            width: 100%;
        }
        
        .nota-info td {
            padding: 8px 0;
            font-size: 14px;
        }
        
        .nota-info .label {
            font-weight: 700;
            color: #1e40af;
            width: 150px;
        }
        
        .nota-info .value {
            color: #333;
            font-weight: 600;
        }
        
        .section-title {
            background: #3b82f6;
            color: white;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 700;
            margin: 30px 0 15px;
            border-radius: 6px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .info-box {
            background: #f9fafb;
            border: 2px solid #e5e7eb;
            padding: 20px;
            margin-bottom: 25px;
            border-radius: 8px;
        }
        
        .info-box h3 {
            color: #1e40af;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-box p {
            margin: 6px 0;
            font-size: 14px;
            color: #4b5563;
        }
        
        .info-box strong {
            color: #1f2937;
            font-weight: 600;
        }
        
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        table.items thead {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }
        
        table.items thead th {
            color: white;
            padding: 15px 12px;
            text-align: left;
            font-weight: 700;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        table.items tbody tr {
            border-bottom: 1px solid #e5e7eb;
            transition: background-color 0.2s;
        }
        
        table.items tbody tr:hover {
            background-color: #f9fafb;
        }
        
        table.items tbody tr:last-child {
            border-bottom: none;
        }
        
        table.items tbody td {
            padding: 14px 12px;
            font-size: 14px;
            color: #4b5563;
        }
        
        table.items tbody td.product-name {
            font-weight: 600;
            color: #1f2937;
        }
        
        table.items tbody td.text-right {
            text-align: right;
        }
        
        table.items tbody td.text-center {
            text-align: center;
        }
        
        .totals {
            margin-top: 30px;
            border-top: 3px solid #3b82f6;
            padding-top: 20px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 20px;
            margin: 8px 0;
            background: #f9fafb;
            border-radius: 6px;
            align-items: center;
        }
        
        .total-row.final {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            font-size: 20px;
            font-weight: 800;
            padding: 18px 20px;
            margin-top: 15px;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .total-row .label {
            font-weight: 700;
            font-size: 15px;
        }
        
        .total-row .value {
            font-weight: 800;
            font-size: 16px;
        }
        
        .total-row.final .label,
        .total-row.final .value {
            font-size: 22px;
            letter-spacing: 1px;
        }
        
        .footer {
            margin-top: 50px;
            padding-top: 25px;
            border-top: 2px solid #e5e7eb;
            text-align: center;
            color: #6b7280;
            font-size: 13px;
        }
        
        .footer p {
            margin: 8px 0;
        }
        
        .footer strong {
            color: #3b82f6;
            font-weight: 700;
        }
        
        .print-button {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            border: none;
            padding: 16px 32px;
            font-size: 16px;
            font-weight: 700;
            border-radius: 50px;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(59, 130, 246, 0.4);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 1000;
        }
        
        .print-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 32px rgba(59, 130, 246, 0.5);
        }
        
        .print-button i {
            font-size: 20px;
        }
        
        .back-button {
            position: fixed;
            bottom: 30px;
            left: 30px;
            background: #6b7280;
            color: white;
            border: none;
            padding: 16px 32px;
            font-size: 16px;
            font-weight: 700;
            border-radius: 50px;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            z-index: 1000;
        }
        
        .back-button:hover {
            background: #4b5563;
            transform: translateY(-3px);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.3);
        }
        
        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-concluida {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-pendente {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-cancelada {
            background: #fee2e2;
            color: #991b1b;
        }
    </style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💎 DIAMOND SYSTEM</h1>
            <p class="subtitle">Nota Fiscal de Venda</p>
        </div>
        
        <div class="nota-info">
            <table>
                <tr>
                    <td class="label">Nota Fiscal Nº:</td>
                    <td class="value"><?php echo $nota_numero; ?></td>
                    <td class="label">Data de Emissão:</td>
                    <td class="value"><?php echo $data_emissao; ?></td>
                </tr>
                <tr>
                    <td class="label">Status:</td>
                    <td class="value">
                        <span class="status-badge status-<?php echo $sale['status']; ?>">
                            <?php echo strtoupper($sale['status']); ?>
                        </span>
                    </td>
                    <td class="label">Forma de Pagamento:</td>
                    <td class="value"><?php echo htmlspecialchars($sale['payment_method']); ?></td>
                </tr>
            </table>
        </div>
        
        <div class="section-title">
            <i class="fas fa-user"></i> Dados do Cliente
        </div>
        
        <div class="info-box">
            <?php if (!empty($sale['client_name'])): ?>
                <h3>Cliente</h3>
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($sale['client_name']); ?></p>
                <?php if (!empty($sale['client_cpf'])): ?>
                    <p><strong>CPF:</strong> <?php echo formatar_cpf($sale['client_cpf']); ?></p>
                <?php endif; ?>
                <?php if (!empty($sale['client_email'])): ?>
                    <p><strong>E-mail:</strong> <?php echo htmlspecialchars($sale['client_email']); ?></p>
                <?php endif; ?>
                <?php if (!empty($sale['client_phone'])): ?>
                    <p><strong>Telefone:</strong> <?php echo formatar_telefone($sale['client_phone']); ?></p>
                <?php endif; ?>
                <?php if (!empty($sale['client_address'])): ?>
                    <p><strong>Endereço:</strong> <?php echo htmlspecialchars($sale['client_address']); ?></p>
                    <p><strong>Cidade/UF:</strong> <?php echo htmlspecialchars($sale['client_city'] . '/' . $sale['client_state']); ?></p>
                    <?php if (!empty($sale['client_postal_code'])): ?>
                        <p><strong>CEP:</strong> <?php echo formatar_cep($sale['client_postal_code']); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <p><strong>Cliente não registrado</strong></p>
            <?php endif; ?>
        </div>
        
        <div class="info-box">
            <h3>Vendedor</h3>
            <p><strong>Nome:</strong> <?php echo htmlspecialchars($sale['user_name']); ?></p>
        </div>
        
        <div class="section-title">
            <i class="fas fa-shopping-cart"></i> Produtos e Serviços
        </div>
        
        <table class="items">
            <thead>
                <tr>
                    <th style="width: 50px;">Item</th>
                    <th>Produto</th>
                    <th style="width: 100px;" class="text-center">Qtd.</th>
                    <th style="width: 120px;" class="text-right">Valor Unit.</th>
                    <th style="width: 120px;" class="text-right">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $item_counter = 1;
                foreach ($items as $item): 
                ?>
                <tr>
                    <td class="text-center"><?php echo $item_counter++; ?></td>
                    <td class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td class="text-center"><?php echo $item['quantity']; ?></td>
                    <td class="text-right"><?php echo format_money($item['price']); ?></td>
                    <td class="text-right"><strong><?php echo format_money($item['subtotal']); ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="totals">
            <div class="total-row final">
                <span class="label">VALOR TOTAL</span>
                <span class="value"><?php echo format_money($sale['total']); ?></span>
            </div>
        </div>
        
        <?php if (!empty($sale['notes'])): ?>
        <div class="section-title">
            <i class="fas fa-sticky-note"></i> Observações
        </div>
        <div class="info-box">
            <p><?php echo nl2br(htmlspecialchars($sale['notes'])); ?></p>
        </div>
        <?php endif; ?>
        
        <div class="footer">
            <p><strong>Diamond System</strong> - Sistema de Gestão Comercial</p>
            <p>Este documento é uma representação simplificada da nota fiscal para controle interno.</p>
            <p>Documento gerado em: <?php echo date('d/m/Y H:i:s'); ?></p>
        </div>
    </div>
    
    <button onclick="window.print()" class="print-button no-print">
        <i class="fas fa-print"></i>
        Imprimir / Salvar PDF
    </button>
    
    <a href="<?php echo BASE_URL; ?>vendas.php" class="back-button no-print">
        <i class="fas fa-arrow-left"></i>
        Voltar
    </a>
    
    <script>
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            window.print();
        }
    });
    </script>
</body>
</html>
