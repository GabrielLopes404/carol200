<?php
header('Location: entrar.php');
exit;
?>
