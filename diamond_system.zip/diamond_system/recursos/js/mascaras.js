// Máscaras de entrada para campos
document.addEventListener('DOMContentLoaded', function() {
    // Máscara de CPF com validação em tempo real
    const cpfInputs = document.querySelectorAll('.cpf-input');
    cpfInputs.forEach(input => {
        input.setAttribute('maxlength', '14');
        
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value.length > 11) {
                value = value.substring(0, 11);
            }
            
            if (value.length <= 11) {
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                e.target.value = value;
            }
        });
        
        input.addEventListener('blur', function(e) {
            const cpf = e.target.value.replace(/\D/g, '');
            const cpfFeedback = e.target.parentElement.querySelector('.cpf-validation-feedback');
            
            if (cpf.length === 0) {
                e.target.classList.remove('is-invalid', 'is-valid');
                if (cpfFeedback) cpfFeedback.remove();
                return;
            }
            
            if (cpf.length === 11) {
                const baseUrl = window.BASE_URL || '/';
                fetch(`${baseUrl}api_validate_cpf.php?cpf=${cpf}`)
                    .then(response => response.json())
                    .then(data => {
                        let feedback = e.target.parentElement.querySelector('.cpf-validation-feedback');
                        
                        if (!data.valido) {
                            e.target.classList.remove('is-valid');
                            e.target.classList.add('is-invalid');
                            
                            if (!feedback) {
                                feedback = document.createElement('div');
                                feedback.className = 'cpf-validation-feedback';
                                feedback.style.cssText = 'margin-top: 6px; font-size: 13px; font-weight: 600;';
                                e.target.parentElement.appendChild(feedback);
                            }
                            feedback.innerHTML = '<i class="fas fa-times-circle me-1"></i>' + data.mensagem;
                            feedback.style.color = '#ef4444';
                        } else {
                            e.target.classList.remove('is-invalid');
                            e.target.classList.add('is-valid');
                            
                            if (!feedback) {
                                feedback = document.createElement('div');
                                feedback.className = 'cpf-validation-feedback';
                                feedback.style.cssText = 'margin-top: 6px; font-size: 13px; font-weight: 600;';
                                e.target.parentElement.appendChild(feedback);
                            }
                            feedback.innerHTML = '<i class="fas fa-check-circle me-1"></i>' + data.mensagem;
                            feedback.style.color = '#10b981';
                        }
                    })
                    .catch(error => console.error('Erro ao validar CPF:', error));
            } else {
                e.target.classList.add('is-invalid');
                e.target.classList.remove('is-valid');
                
                let feedback = e.target.parentElement.querySelector('.cpf-validation-feedback');
                if (!feedback) {
                    feedback = document.createElement('div');
                    feedback.className = 'cpf-validation-feedback';
                    feedback.style.cssText = 'margin-top: 6px; font-size: 13px; font-weight: 600;';
                    e.target.parentElement.appendChild(feedback);
                }
                feedback.innerHTML = '<i class="fas fa-exclamation-circle me-1"></i>CPF deve ter 11 dígitos';
                feedback.style.color = '#f59e0b';
            }
        });
    });
    
    // Máscara de telefone com limite de caracteres
    const phoneInputs = document.querySelectorAll('.phone-input');
    phoneInputs.forEach(input => {
        input.setAttribute('maxlength', '15');
        
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value.length > 11) {
                value = value.substring(0, 11);
            }
            
            if (value.length <= 11) {
                if (value.length <= 10) {
                    value = value.replace(/(\d{2})(\d)/, '($1) $2');
                    value = value.replace(/(\d{4})(\d)/, '$1-$2');
                } else {
                    value = value.replace(/(\d{2})(\d)/, '($1) $2');
                    value = value.replace(/(\d{5})(\d)/, '$1-$2');
                }
                e.target.value = value;
            }
        });
    });
    
    // Máscara de CEP
    const cepInputs = document.querySelectorAll('.cep-input');
    cepInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length <= 8) {
                value = value.replace(/(\d{5})(\d)/, '$1-$2');
                e.target.value = value;
            }
        });
    });
    
    // Máscara de dinheiro
    const moneyInputs = document.querySelectorAll('.money-input');
    moneyInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (parseInt(value) / 100).toFixed(2);
            value = value.replace('.', ',');
            value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            e.target.value = value;
        });
    });
    
    // Buscar CEP
    const btnBuscarCep = document.getElementById('btn-buscar-cep');
    if (btnBuscarCep) {
        btnBuscarCep.addEventListener('click', function() {
            const cepInput = document.getElementById('postal_code');
            const cep = cepInput.value.replace(/\D/g, '');
            
            if (cep.length !== 8) {
                alert('CEP inválido!');
                return;
            }
            
            btnBuscarCep.disabled = true;
            btnBuscarCep.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            const baseUrl = window.BASE_URL || '/';
            fetch(`${baseUrl}api_cep.php?cep=${cep}`)
                .then(response => response.json())
                .then(data => {
                    if (data.erro) {
                        alert(data.mensagem || 'CEP não encontrado');
                    } else {
                        document.getElementById('address').value = data.logradouro || '';
                        document.getElementById('city').value = data.localidade || '';
                        document.getElementById('state').value = data.uf || '';
                    }
                })
                .catch(error => {
                    alert('Erro ao buscar CEP');
                    console.error(error);
                })
                .finally(() => {
                    btnBuscarCep.disabled = false;
                    btnBuscarCep.innerHTML = '<i class="fas fa-search"></i>';
                });
        });
    }
    
    // Auto-hide alerts
    setTimeout(() => {
        const alerts = document.querySelectorAll('.notification-alert');
        alerts.forEach(alert => {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 300);
        });
    }, 5000);
});
