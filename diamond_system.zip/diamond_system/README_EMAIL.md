# Configuração de E-mail para Recuperação de Senha

## 📧 Como Configurar o Envio de E-mails

Para que o sistema de recuperação de senha funcione corretamente, você precisa configurar as credenciais SMTP no arquivo `configuracao/email_config.php`.

### Opção 1: Usar Gmail (Recomendado para testes)

1. Abra o arquivo `configuracao/email_config.php`

2. Configure com suas credenciais do Gmail:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'seuemail@gmail.com');
define('SMTP_PASS', 'sua-senha-de-app');
define('SMTP_FROM_EMAIL', 'seuemail@gmail.com');
define('SMTP_FROM_NAME', 'Diamond System');
define('SMTP_ENCRYPTION', 'tls');
```

3. **IMPORTANTE**: Para usar Gmail, você precisa gerar uma "Senha de App":
   - Acesse: https://myaccount.google.com/security
   - Ative a verificação em 2 etapas
   - Vá em "Senhas de app"
   - Gere uma senha para "Outro (nome personalizado)"
   - Use essa senha gerada no campo `SMTP_PASS`

### Opção 2: Usar Outro Provedor SMTP

#### Outlook/Hotmail:
```php
define('SMTP_HOST', 'smtp-mail.outlook.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'seuemail@outlook.com');
define('SMTP_PASS', 'sua-senha');
define('SMTP_FROM_EMAIL', 'seuemail@outlook.com');
define('SMTP_FROM_NAME', 'Diamond System');
define('SMTP_ENCRYPTION', 'tls');
```

#### SendGrid (Serviço profissional):
```php
define('SMTP_HOST', 'smtp.sendgrid.net');
define('SMTP_PORT', 587);
define('SMTP_USER', 'apikey');
define('SMTP_PASS', 'SUA-API-KEY-AQUI');
define('SMTP_FROM_EMAIL', 'seuemail@seudominio.com');
define('SMTP_FROM_NAME', 'Diamond System');
define('SMTP_ENCRYPTION', 'tls');
```

#### Mailgun:
```php
define('SMTP_HOST', 'smtp.mailgun.org');
define('SMTP_PORT', 587);
define('SMTP_USER', 'postmaster@seudominio.mailgun.org');
define('SMTP_PASS', 'sua-senha-mailgun');
define('SMTP_FROM_EMAIL', 'noreply@seudominio.com');
define('SMTP_FROM_NAME', 'Diamond System');
define('SMTP_ENCRYPTION', 'tls');
```

## 🧪 Testando o Sistema

1. Acesse a página "Esqueci minha senha"
2. Digite um e-mail cadastrado no sistema
3. Verifique a caixa de entrada (e spam) do e-mail
4. Clique no link recebido para redefinir a senha

## ⚠️ Solução de Problemas

### Erro: "Não foi possível conectar ao servidor SMTP"
- Verifique se o `SMTP_HOST` e `SMTP_PORT` estão corretos
- Verifique se seu firewall permite conexões SMTP
- Tente alterar a porta (587 ou 465)

### Erro: "Senha inválida"
- Verifique se está usando a senha correta
- Para Gmail, certifique-se de usar a "Senha de App", não a senha normal
- Verifique se a autenticação em 2 etapas está ativa (Gmail)

### E-mail não chega
- Verifique a pasta de spam
- Verifique se o e-mail do remetente está configurado corretamente
- Teste com outro provedor de e-mail

### Erro: "Configurações SMTP não definidas"
- Certifique-se de que preencheu todos os campos em `email_config.php`
- Não deixe as aspas vazias

## 🔒 Segurança

- **NUNCA** commit o arquivo `email_config.php` com suas credenciais reais
- Adicione `email_config.php` ao `.gitignore`
- Use variáveis de ambiente em produção
- Mantenha suas senhas de app seguras

## 📝 Exemplo de .gitignore

Adicione ao seu `.gitignore`:
```
configuracao/email_config.php
```

## 💡 Dicas

1. **Para desenvolvimento**: Use um e-mail de teste (Mailtrap, Ethereal Email)
2. **Para produção**: Use um serviço profissional (SendGrid, Mailgun, AWS SES)
3. **Limite de envios**: Gmail tem limite de 500 e-mails/dia
4. **Monitoramento**: Implemente logs para rastrear e-mails enviados

## 🎯 Funcionalidades Implementadas

✅ Envio de e-mail com template HTML responsivo e moderno
✅ Link de redefinição com token seguro
✅ Expiração automática do link após 1 hora
✅ Proteção contra uso múltiplo do mesmo token
✅ Mensagens de erro amigáveis e informativas
✅ Suporte para TLS/SSL
✅ Template de e-mail profissional com design moderno
