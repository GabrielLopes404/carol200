<?php

namespace PHPMailer\PHPMailer;

class PHPMailer
{
    public $SMTPDebug = 0;
    public $CharSet = 'UTF-8';
    public $Host;
    public $SMTPAuth;
    public $Username;
    public $Password;
    public $SMTPSecure;
    public $Port;
    public $Subject;
    public $Body;
    public $AltBody;
    public $ErrorInfo = '';
    
    private $to = [];
    private $from = [];
    private $replyTo = [];
    private $isHTML = false;
    
    public function __construct($exceptions = false)
    {
    }
    
    public function isSMTP()
    {
        return true;
    }
    
    public function setFrom($address, $name = '')
    {
        $this->from = ['address' => $address, 'name' => $name];
        return true;
    }
    
    public function addAddress($address, $name = '')
    {
        $this->to[] = ['address' => $address, 'name' => $name];
        return true;
    }
    
    public function addReplyTo($address, $name = '')
    {
        $this->replyTo = ['address' => $address, 'name' => $name];
        return true;
    }
    
    public function isHTML($isHTML = true)
    {
        $this->isHTML = $isHTML;
    }
    
    public function send()
    {
        if (empty($this->Host) || empty($this->Username) || empty($this->Password)) {
            $this->ErrorInfo = 'Configurações SMTP não definidas. Configure em configuracao/email_config.php';
            throw new \Exception($this->ErrorInfo);
        }
        
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ]);
        
        $socket = @stream_socket_client(
            "{$this->Host}:{$this->Port}",
            $errno,
            $errstr,
            30,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        if (!$socket) {
            $this->ErrorInfo = "Não foi possível conectar ao servidor SMTP: $errstr ($errno)";
            throw new \Exception($this->ErrorInfo);
        }
        
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '220') {
            $this->ErrorInfo = "Resposta inesperada do servidor: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        fputs($socket, "EHLO " . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "\r\n");
        $response = '';
        while ($str = fgets($socket, 515)) {
            $response .= $str;
            if (substr($str, 3, 1) == ' ') break;
        }
        
        if ($this->SMTPSecure === 'tls') {
            fputs($socket, "STARTTLS\r\n");
            $response = fgets($socket, 515);
            
            if (substr($response, 0, 3) != '220') {
                $this->ErrorInfo = "Erro ao iniciar TLS: $response";
                fclose($socket);
                throw new \Exception($this->ErrorInfo);
            }
            
            $crypto_method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
                $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
            }
            
            if (!stream_socket_enable_crypto($socket, true, $crypto_method)) {
                $this->ErrorInfo = "Erro ao habilitar criptografia TLS";
                fclose($socket);
                throw new \Exception($this->ErrorInfo);
            }
            
            fputs($socket, "EHLO " . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "\r\n");
            $response = '';
            while ($str = fgets($socket, 515)) {
                $response .= $str;
                if (substr($str, 3, 1) == ' ') break;
            }
        }
        
        fputs($socket, "AUTH LOGIN\r\n");
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '334') {
            $this->ErrorInfo = "Erro na autenticação (AUTH LOGIN não suportado): $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        fputs($socket, base64_encode($this->Username) . "\r\n");
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '334') {
            $this->ErrorInfo = "Usuário inválido: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        fputs($socket, base64_encode($this->Password) . "\r\n");
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '235') {
            $this->ErrorInfo = "Senha inválida ou autenticação falhou: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        fputs($socket, "MAIL FROM: <{$this->from['address']}>\r\n");
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '250') {
            $this->ErrorInfo = "Erro ao definir remetente: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        foreach ($this->to as $recipient) {
            fputs($socket, "RCPT TO: <{$recipient['address']}>\r\n");
            $response = fgets($socket, 515);
            
            if (substr($response, 0, 3) != '250') {
                $this->ErrorInfo = "Erro ao definir destinatário {$recipient['address']}: $response";
                fclose($socket);
                throw new \Exception($this->ErrorInfo);
            }
        }
        
        fputs($socket, "DATA\r\n");
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '354') {
            $this->ErrorInfo = "Erro ao iniciar envio de dados: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        $date = date('r');
        $message_id = '<' . md5(uniqid(time())) . '@' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '>';
        
        $headers = "Date: $date\r\n";
        $headers .= "Message-ID: $message_id\r\n";
        $headers .= "From: {$this->from['name']} <{$this->from['address']}>\r\n";
        
        $to_header = '';
        foreach ($this->to as $recipient) {
            if (!empty($to_header)) $to_header .= ', ';
            $to_header .= !empty($recipient['name']) ? 
                "{$recipient['name']} <{$recipient['address']}>" : 
                $recipient['address'];
        }
        $headers .= "To: $to_header\r\n";
        
        $headers .= "Subject: {$this->Subject}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        
        if ($this->isHTML) {
            $headers .= "Content-Type: text/html; charset={$this->CharSet}\r\n";
        } else {
            $headers .= "Content-Type: text/plain; charset={$this->CharSet}\r\n";
        }
        
        $headers .= "Content-Transfer-Encoding: 8bit\r\n";
        $headers .= "X-Mailer: Diamond System PHPMailer\r\n";
        
        $body = str_replace("\n.", "\n..", $this->Body);
        
        $message = $headers . "\r\n" . $body . "\r\n.\r\n";
        
        fputs($socket, $message);
        $response = fgets($socket, 515);
        
        if (substr($response, 0, 3) != '250') {
            $this->ErrorInfo = "Erro ao enviar mensagem: $response";
            fclose($socket);
            throw new \Exception($this->ErrorInfo);
        }
        
        fputs($socket, "QUIT\r\n");
        fgets($socket, 515);
        fclose($socket);
        
        return true;
    }
}
?>
