<?php
class Category {
    private $conn;
    private $table = 'categories';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($name, $description) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (name, description) VALUES (:name, :description)");
        
        return $stmt->execute([
            'name' => $name,
            'description' => $description
        ]);
    }
    
    public function update($id, $name, $description) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, description = :description WHERE id = :id");
        
        return $stmt->execute([
            'name' => $name,
            'description' => $description,
            'id' => $id
        ]);
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = :id");
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();
        
        if ($result['count'] > 0) {
            return false;
        }
        
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY name ASC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    public function getAllWithProductCount() {
        $stmt = $this->conn->query("SELECT c.*, COUNT(p.id) as product_count FROM {$this->table} c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id ORDER BY c.name ASC");
        return $stmt->fetchAll();
    }
}
?>
