<?php
namespace PHPMailer\PHPMailer;

class Exception extends \Exception
{
}
?>
