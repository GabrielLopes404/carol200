<?php
namespace PHPMailer\PHPMailer;

class SMTP
{
}
?>
