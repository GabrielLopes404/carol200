<?php
class SimplePDF {
    private $content = '';
    private $title = '';
    
    public function __construct($title = 'Documento') {
        $this->title = $title;
    }
    
    public function addTitle($text) {
        $this->content .= '<h1 style="color: #3b82f6; border-bottom: 3px solid #3b82f6; padding-bottom: 10px; font-family: Arial, sans-serif;">' . $text . '</h1>';
    }
    
    public function addSubtitle($text) {
        $this->content .= '<h2 style="color: #1e40af; margin-top: 30px; font-family: Arial, sans-serif;">' . $text . '</h2>';
    }
    
    public function addParagraph($text) {
        $this->content .= '<p style="font-family: Arial, sans-serif; line-height: 1.6;">' . $text . '</p>';
    }
    
    public function addTable($headers, $rows) {
        $table = '<table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse; margin: 20px 0; font-family: Arial, sans-serif;">';
        
        // Headers
        $table .= '<thead><tr style="background-color: #3b82f6;">';
        foreach ($headers as $header) {
            $table .= '<th style="color: white; padding: 12px; text-align: left;">' . $header . '</th>';
        }
        $table .= '</tr></thead>';
        
        // Rows
        $table .= '<tbody>';
        foreach ($rows as $row) {
            $table .= '<tr style="border-bottom: 1px solid #e5e7eb;">';
            foreach ($row as $cell) {
                $table .= '<td style="padding: 10px;">' . $cell . '</td>';
            }
            $table .= '</tr>';
        }
        $table .= '</tbody></table>';
        
        $this->content .= $table;
    }
    
    public function output($filename = 'documento.pdf', $mode = 'I') {
        // Modo I = Inline (visualizar no navegador)
        // Modo D = Download
        
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>' . $this->title . '</title>
    <style>
        @page { margin: 2cm; }
        body { font-family: Arial, sans-serif; font-size: 12pt; }
        h1 { color: #3b82f6; border-bottom: 3px solid #3b82f6; padding-bottom: 10px; }
        h2 { color: #1e40af; margin-top: 30px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background-color: #3b82f6; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #e5e7eb; }
        tr:hover { background-color: #f3f4f6; }
    </style>
</head>
<body>
' . $this->content . '
</body>
</html>';

        // Para visualização inline, vamos usar wkhtmltopdf se disponível, senão renderizamos HTML
        if ($mode == 'I') {
            // Verificar se wkhtmltopdf está disponível
            $wkhtmltopdf = shell_exec('which wkhtmltopdf 2>/dev/null');
            
            if (!empty($wkhtmltopdf)) {
                // Usar wkhtmltopdf
                $tempHtml = sys_get_temp_dir() . '/' . uniqid() . '.html';
                $tempPdf = sys_get_temp_dir() . '/' . uniqid() . '.pdf';
                
                file_put_contents($tempHtml, $html);
                shell_exec("wkhtmltopdf $tempHtml $tempPdf 2>/dev/null");
                
                if (file_exists($tempPdf)) {
                    header('Content-Type: application/pdf');
                    header('Content-Disposition: inline; filename="' . $filename . '"');
                    readfile($tempPdf);
                    unlink($tempHtml);
                    unlink($tempPdf);
                    exit;
                }
            }
            
            // Fallback: renderizar como HTML com aparência de PDF
            header('Content-Type: text/html; charset=utf-8');
            echo $html;
        } else {
            // Download como HTML (navegador pode salvar como PDF)
            header('Content-Type: text/html; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . str_replace('.pdf', '.html', $filename) . '"');
            echo $html;
        }
        exit;
    }
}
?>
