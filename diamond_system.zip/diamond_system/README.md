# 💎 Diamond System - Sistema de Gestão Comercial

Sistema profissional de gestão comercial desenvolvido em PHP com design moderno e funcionalidades completas.

## 🚀 Funcionalidades Implementadas

### ✅ **Permissões por Tipo de Usuário**
- **Administrador**: Acesso total ao sistema
- **Gerente**: Gerenciar produtos, clientes e vendas
- **Vendedor**: 
  - ✅ Pode **editar clientes** (mas não criar ou excluir)
  - ✅ **NÃO pode editar ou excluir produtos** (apenas visualizar)
  - ✅ Pode realizar vendas e visualizar relatórios

### 📧 **Recuperação de Senha com E-mail Real**
- Sistema 100% funcional de recuperação de senha
- Envio de e-mail real via SMTP com template HTML profissional
- Token seguro com expiração de 1 hora
- Proteção contra reuso do mesmo token
- Suporte a Gmail, Outlook, SendGrid, Mailgun e outros provedores SMTP

### 🖼️ **Visualização de Imagens em Tela Cheia (Lightbox)**
- Lightbox moderno e responsivo na vitrine de produtos
- Clique na foto do produto para visualizar em tela cheia
- Animações suaves e design profissional
- Fechar com ESC ou clicando fora da imagem
- Ícone de zoom aparece ao passar o mouse

### 📄 **Impressão de Nota Fiscal em PDF**
- Sistema profissional de geração de nota fiscal
- Design limpo e moderno
- Botão "Imprimir Nota Fiscal" nas páginas de vendas e detalhes
- Imprime direto do navegador (Ctrl+P ou usar botão)
- Salva como PDF através da função de impressão do navegador
- Informações completas: cliente, produtos, valores, vendedor

### 🔒 **Segurança e Validações**
- Validação completa de estoque antes de realizar vendas
- Proteção contra SQL Injection (prepared statements)
- Proteção contra XSS (htmlspecialchars em todas saídas)
- Validação de tipos de dados (int, float)
- Logs de erros para debugging
- Senhas com hash seguro (bcrypt)

## 📋 Requisitos do Sistema

- **PHP**: 7.4 ou superior
- **MySQL**: 5.7 ou superior
- **Servidor Web**: Apache ou Nginx
- **Extensões PHP necessárias**:
  - PDO
  - PDO_MySQL
  - mbstring
  - curl
  - openssl

## 🛠️ Instalação Local

### 1. Instalar XAMPP ou WAMP
Download do XAMPP: https://www.apachefriends.org/

### 2. Configurar o Banco de Dados

1. Abra o **phpMyAdmin** (http://localhost/phpmyadmin)
2. Crie um novo banco de dados chamado `diamond_system`
3. Importe o arquivo `banco_dados.sql`

### 3. Configurar o Sistema

1. Copie a pasta `diamond_system` para:
   - **XAMPP**: `C:\xampp\htdocs\`
   - **WAMP**: `C:\wamp64\www\`

2. Edite o arquivo `configuracao/config.php` e ajuste se necessário:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'diamond_system');
define('BASE_URL', '/diamond_system/');
```

3. **Configurar E-mail (Recuperação de Senha)**:
   - Edite `configuracao/email_config.php`
   - Veja instruções detalhadas em `README_EMAIL.md`

### 4. Acessar o Sistema

1. Inicie o Apache e MySQL no XAMPP/WAMP
2. Acesse: **http://localhost/diamond_system/**

**Login padrão:**
- Usuário: `admin`
- Senha: `admin123`

## 📱 Páginas e Funcionalidades

### 🏠 Painel Principal
- Dashboard com estatísticas em tempo real
- Gráficos de vendas
- Produtos em baixo estoque
- Vendas recentes

### 💎 Produtos
- Listagem completa de produtos
- Criar, editar e visualizar produtos
- Upload de imagens
- Controle de estoque
- Categorização

### 👥 Clientes
- Cadastro completo de clientes
- Validação de CPF
- Busca de CEP automática (ViaCEP)
- Histórico de compras

### 🛒 Vendas
- Registro de vendas com múltiplos itens
- Seleção de produtos com controle de estoque
- Diferentes formas de pagamento
- **Impressão de Nota Fiscal**

### 🖼️ Vitrine
- Visualização moderna dos produtos
- Busca e filtros por categoria
- Modo grade e lista
- **Lightbox para visualizar imagens em tela cheia**

### 📊 Relatórios
- Vendas por período
- Produtos mais vendidos
- Clientes mais frequentes
- Métodos de pagamento

### 👤 Usuários (Admin)
- Gerenciamento de usuários
- Níveis de permissão (Admin, Gerente, Vendedor)
- Primeiro acesso com troca de senha

## 🎨 Design e Interface

- **Framework CSS**: Bootstrap 5.3
- **Ícones**: Font Awesome 6.4
- **Tema**: Moderno com gradientes azul/roxo
- **Responsivo**: Funciona em desktop, tablet e mobile
- **Animações**: Suaves e profissionais
- **Notificações**: Alertas animados e elegantes

## 🔐 Segurança

### Proteções Implementadas:
- ✅ **SQL Injection**: Prepared statements em todas as queries
- ✅ **XSS**: htmlspecialchars() em todas as saídas
- ✅ **CSRF**: Tokens CSRF em formulários críticos
- ✅ **Senhas**: Hash bcrypt (password_hash)
- ✅ **Validações**: Servidor e cliente
- ✅ **Controle de Acesso**: Verificação de permissões por página
- ✅ **Upload Seguro**: Validação de tipo e tamanho de arquivo

## 📧 Configuração de E-mail

Para ativar o envio de e-mails de recuperação de senha:

1. Edite `configuracao/email_config.php`
2. Configure com suas credenciais SMTP
3. Veja instruções completas em `README_EMAIL.md`

**Provedores suportados:**
- Gmail (com senha de app)
- Outlook/Hotmail
- SendGrid
- Mailgun
- Qualquer servidor SMTP

## 🐛 Solução de Problemas

### Erro de conexão com banco de dados
- Verifique se MySQL está rodando
- Confirme as credenciais em `config.php`
- Certifique-se que o banco `diamond_system` foi criado

### Imagens não aparecem
- Verifique permissões da pasta `recursos/envios/produtos/`
- No Windows: permissões completas para Everyone
- No Linux: `chmod 777 recursos/envios/produtos/`

### E-mail não envia
- Verifique configurações em `email_config.php`
- Use senha de app do Gmail (não a senha normal)
- Teste com outro provedor SMTP

### Erro de permissões
- Faça logout e login novamente
- Verifique o papel do usuário no banco de dados

## 🔄 Atualizações Implementadas

### Versão Atual (2025)

#### Permissões de Vendedor
- Vendedores não podem criar ou excluir clientes
- Vendedores podem apenas editar clientes existentes
- Vendedores não podem criar, editar ou excluir produtos
- Vendedores podem apenas visualizar produtos

#### Sistema de E-mail
- PHPMailer customizado 100% funcional
- Suporte completo a SMTP com TLS/SSL
- Template HTML responsivo e profissional
- Tratamento completo de erros

#### Lightbox na Vitrine
- Visualização em tela cheia ao clicar na imagem
- Design moderno com animações
- Ícone de zoom que aparece no hover
- Fechar com ESC ou clicando fora

#### Nota Fiscal PDF
- Botão em vendas e detalhes da venda
- Design profissional e limpo
- Todas informações completas
- Imprime direto do navegador

#### Validações e Segurança
- Validação de estoque antes de venda
- Validação de tipos de dados
- Tratamento de exceções
- Logs de erro para debugging

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique este README
2. Consulte `README_EMAIL.md` para configuração de e-mail
3. Verifique os logs de erro do PHP
4. Revise as configurações do banco de dados

## 📄 Licença

Sistema desenvolvido para uso comercial interno.

## 🎯 Status do Projeto

✅ **100% Funcional e Pronto para Produção**
- Todas funcionalidades testadas
- Código otimizado e profissional
- Segurança implementada
- Design moderno e responsivo
- Documentação completa

---

**Desenvolvido com 💎 por Diamond System Team**
