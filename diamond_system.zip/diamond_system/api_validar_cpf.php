<?php
header('Content-Type: application/json');

function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    if (strlen($cpf) != 11) {
        return ['valido' => false, 'mensagem' => 'CPF deve ter 11 dígitos'];
    }
    
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return ['valido' => false, 'mensagem' => 'CPF inválido'];
    }
    
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return ['valido' => false, 'mensagem' => 'CPF inválido'];
        }
    }
    
    return ['valido' => true, 'mensagem' => 'CPF válido'];
}

$cpf = $_GET['cpf'] ?? $_POST['cpf'] ?? '';

if (empty($cpf)) {
    echo json_encode(['valido' => false, 'mensagem' => 'CPF não informado']);
    exit;
}

$resultado = validarCPF($cpf);
echo json_encode($resultado);
?>
