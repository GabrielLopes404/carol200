<?php

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_FROM_EMAIL', '');
define('SMTP_FROM_NAME', 'Diamond System');
define('SMTP_ENCRYPTION', 'tls');

function send_email($to_email, $to_name, $subject, $body) {
    require_once __DIR__ . '/../classes/PHPMailer.php';
    require_once __DIR__ . '/../classes/SMTP.php';
    require_once __DIR__ . '/../classes/Exception.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USER;
        $mail->Password = SMTP_PASS;
        $mail->SMTPSecure = SMTP_ENCRYPTION;
        $mail->Port = SMTP_PORT;
        $mail->CharSet = 'UTF-8';
        
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $to_name);
        
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Erro ao enviar email: {$mail->ErrorInfo}");
        return false;
    }
}

function send_password_reset_email($user_email, $user_name, $reset_token) {
    $reset_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . 
                  "://" . $_SERVER['HTTP_HOST'] . 
                  dirname($_SERVER['PHP_SELF']) . 
                  "/redefinir_senha.php?token=" . $reset_token;
    
    $subject = "Recuperação de Senha - Diamond System";
    
    $body = "
    <!DOCTYPE html>
    <html lang='pt-BR'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                padding: 40px 20px;
            }
            .container {
                max-width: 600px;
                margin: 0 auto;
                background: #ffffff;
                border-radius: 16px;
                overflow: hidden;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            }
            .header {
                background: linear-gradient(135deg, #3b82f6, #8b5cf6);
                padding: 40px 30px;
                text-align: center;
                color: white;
            }
            .header h1 {
                margin: 0;
                font-size: 28px;
                font-weight: 800;
            }
            .header p {
                margin: 10px 0 0;
                font-size: 14px;
                opacity: 0.9;
            }
            .content {
                padding: 40px 30px;
                color: #333;
                line-height: 1.6;
            }
            .content h2 {
                color: #3b82f6;
                margin-top: 0;
                font-size: 22px;
            }
            .btn {
                display: inline-block;
                padding: 16px 40px;
                background: linear-gradient(135deg, #3b82f6, #8b5cf6);
                color: white !important;
                text-decoration: none;
                border-radius: 12px;
                font-weight: 700;
                font-size: 16px;
                margin: 20px 0;
                box-shadow: 0 8px 24px rgba(59, 130, 246, 0.4);
                transition: all 0.3s;
            }
            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 12px 32px rgba(59, 130, 246, 0.5);
            }
            .info-box {
                background: #f8f9fa;
                border-left: 4px solid #3b82f6;
                padding: 15px 20px;
                margin: 20px 0;
                border-radius: 8px;
            }
            .info-box strong {
                color: #3b82f6;
            }
            .footer {
                background: #f8f9fa;
                padding: 25px 30px;
                text-align: center;
                color: #666;
                font-size: 13px;
                border-top: 1px solid #e0e0e0;
            }
            .footer p {
                margin: 5px 0;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🔐 Recuperação de Senha</h1>
                <p>Diamond System - Gestão Comercial</p>
            </div>
            <div class='content'>
                <h2>Olá, " . htmlspecialchars($user_name) . "!</h2>
                <p>Recebemos uma solicitação para redefinir a senha da sua conta no <strong>Diamond System</strong>.</p>
                
                <p>Para criar uma nova senha, clique no botão abaixo:</p>
                
                <div style='text-align: center;'>
                    <a href='" . $reset_link . "' class='btn'>Redefinir Minha Senha</a>
                </div>
                
                <div class='info-box'>
                    <p><strong>⏱️ Link válido por 1 hora</strong></p>
                    <p style='margin: 0;'>Por segurança, este link expira em 60 minutos.</p>
                </div>
                
                <p>Se você não conseguir clicar no botão, copie e cole o link abaixo no seu navegador:</p>
                <p style='background: #f8f9fa; padding: 12px; border-radius: 8px; word-wrap: break-word; font-size: 13px; color: #666;'>" . $reset_link . "</p>
                
                <div class='info-box'>
                    <p><strong>🛡️ Não solicitou esta alteração?</strong></p>
                    <p style='margin: 0;'>Se você não pediu para redefinir sua senha, ignore este e-mail. Sua senha permanecerá segura.</p>
                </div>
            </div>
            <div class='footer'>
                <p><strong>Diamond System</strong> - Sistema de Gestão Comercial</p>
                <p>Este é um e-mail automático. Por favor, não responda.</p>
                <p style='margin-top: 15px; font-size: 11px; color: #999;'>© " . date('Y') . " Diamond System. Todos os direitos reservados.</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return send_email($user_email, $user_name, $subject, $body);
}
?>
